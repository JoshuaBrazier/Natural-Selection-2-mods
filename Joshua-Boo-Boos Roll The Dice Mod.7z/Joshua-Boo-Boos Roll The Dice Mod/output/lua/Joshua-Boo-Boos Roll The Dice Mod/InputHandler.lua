local keyBinding = debug.getupvaluex(Input_SyncInputOptions, "_keyBinding")
keyBinding.RollTheDice     = InputKey.None
