local kUmbraModifier = debug.getupvaluex(UmbraMixin.ModifyDamageTaken, "kUmbraModifier")
kUmbraModifier["Mac10"] = kUmbraBulletModifier