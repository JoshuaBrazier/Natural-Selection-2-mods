local RTD_Table = {
    entityId = "entityid"
    }

local RTD_Server_Relay_Table = {
    entityId = 'entityid',
    newXP = 'float'
    }
Shared.RegisterNetworkMessage("RTD", RTD_Table)

Shared.RegisterNetworkMessage("RTD_Server_Relay", RTD_Server_Relay_Table)

if Client then

    function Client_Handle_RTD_Update(table)
        Shared.Message("CLIENT HAS RECEIVED RELAY INFORMATION")
    
        local player = Shared.GetEntity(table.entityId)
        local newXPVal = table.newXP
    
        player.score = newXPVal
        player.combatTable.lvl = player:GetLvl()
    end

    Client.HookNetworkMessage("RTD_Server_Relay", Client_Handle_RTD_Update)

end

if Server then

    function Server_Listen_RTD(table)
        
        Shared.Message("SERVER REGISTERED RTD REQUEST")
    
        local playerEntity = Shared.GetEntity(table.entityId)
        
        local gainedXP = math.ceil(0.5 * (Experience_XpForLvl(playerEntity:GetLvl()+1) - Experience_XpForLvl(playerEntity:GetLvl())))
        local RTD_New_XP = Experience_XpForLvl(playerEntity:GetLvl()) + gainedXP
        playerEntity.score = RTD_New_XP
        playerEntity.combatTable.lvl = playerEntity:GetLvl()
    
        local players = GetEntities("Player")
        for i = 1, #players do
            Server.SendNetworkMessage(players[i], "RTD_Server_Relay",
                            {
                                table.entityId,
                                RTD_New_XP
                            }, true)
            players[i]:SendDirectMessage(string.format("Player %s rolled a 1! %s got %i XP!", player:GetName(), gainedXP))
        end
    end

    Server.HookNetworkMessage("RTD", Server_Listen_RTD)

end