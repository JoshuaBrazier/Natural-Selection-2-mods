function ChatUI_SubmitChatMessageBody(chatMessage)

    -- Quote string so spacing doesn't come through as multiple arguments
    if chatMessage ~= nil and string.len(chatMessage) > 0 then
    
        chatMessage = string.UTF8Sub(chatMessage, 1, kMaxChatLength)

        if chatMessage == "!rtd" then
            local player = Client.GetLocalPlayer()
            if player then
                local id = player:GetId()
                Client.SendNetworkMessage("RTD",
                    {
                        id,
                    }, true)

                    -- entityId = player:GetId(),
                    -- random_string = "123"

                Shared.Message("CLIENT SENT NETWORK MESSAGE RTD WITH ID " .. player:GetId())
            end

        end

        Client.SendNetworkMessage("ChatClient", BuildChatClientMessage(teamOnlyChat, chatMessage), true)
        
        teamOnlyChat = false
        
    end
    
    enteringChatMessage = false
    
    SetMoveInputBlocked(false)
    
end