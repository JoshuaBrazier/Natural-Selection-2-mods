if Client then
	kBmacMaterialViewIndices["Mac10"] = 0
end