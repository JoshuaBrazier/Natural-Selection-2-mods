debug.appendtoenum(kPlayerStatus, "Mac10")
debug.appendtoenum(kDeathMessageIcon, "Mac10")