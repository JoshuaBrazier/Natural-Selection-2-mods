kMac10Damage = 10
kMac10DamageType = kDamageType.Normal
-- not used yet
kMac10DropCost = 3
kMac10TechResearchCost = 20
kMac10TechResearchTime = 5
kMac10Cost = 3
kMac10PointValue = 3